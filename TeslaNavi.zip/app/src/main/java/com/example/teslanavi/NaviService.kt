package com.example.teslanavi

import android.app.*
import android.content.Intent
import android.os.IBinder
import com.google.android.gms.location.*
import kotlinx.coroutines.*

/** 폰 GPS로 감시하다가 경유지 반경 안에 들어오면 다음 목적지를 테슬라로 전송 */
class NaviService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var fused: FusedLocationProviderClient? = null
    private var cb: LocationCallback? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun note(t: String) = Notification.Builder(this, "n")
        .setContentTitle("테슬라 순차 안내").setContentText(t)
        .setSmallIcon(android.R.drawable.ic_menu_directions).build()

    private fun send(p: Prefs, pt: Pt) = scope.launch {
        val msg = runCatching { Api.tesla(p, pt) }
            .fold({ "전송 완료 (${"%.4f".format(pt.lat)}, ${"%.4f".format(pt.lng)})" }, { "전송 실패: ${it.message}" })
        getSystemService(NotificationManager::class.java).notify(1, note(msg))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val raw = i?.getDoubleArrayExtra("wps") ?: return START_NOT_STICKY
        val wps = raw.toList().chunked(2).map { Pt(it[0], it[1]) }
        val radius = i.getDoubleExtra("radius", 1000.0)
        val p = Prefs(this)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("n", "순차 주행", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, note("시작"))
        send(p, wps[0])
        if (wps.size == 1) { stopSelf(); return START_NOT_STICKY }

        var idx = 0
        fused = LocationServices.getFusedLocationProviderClient(this)
        cb = object : LocationCallback() {
            override fun onLocationResult(r: LocationResult) {
                val l = r.lastLocation ?: return
                if (Api.dist(Pt(l.latitude, l.longitude), wps[idx]) <= radius) {
                    idx++; send(p, wps[idx])
                    if (idx == wps.lastIndex) stopSelf()
                }
            }
        }
        @Suppress("MissingPermission")
        fused!!.requestLocationUpdates(LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000).build(), cb!!, mainLooper)
        return START_NOT_STICKY
    }

    override fun onDestroy() { cb?.let { fused?.removeLocationUpdates(it) } }
}
