package com.example.teslanavi

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlin.math.*

data class Pt(val lat: Double, val lng: Double)

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("s", Context.MODE_PRIVATE)
    fun get(k: String) = p.getString(k, "") ?: ""
    fun put(k: String, v: String) = p.edit().putString(k, v).apply()
}

object Api {
    private val http = OkHttpClient()
    private const val NAVER = "https://maps.apigw.ntruss.com"

    private fun naver(p: Prefs, url: String): JSONObject {
        val r = Request.Builder().url(url)
            .header("X-NCP-APIGW-API-KEY-ID", p.get("nid"))
            .header("X-NCP-APIGW-API-KEY", p.get("nsecret")).build()
        return http.newCall(r).execute().use { JSONObject(it.body!!.string()) }
    }

    /** "37.49,127.02" 형태면 좌표로, 아니면 주소로 지오코딩 */
    fun geocode(p: Prefs, q: String): Pt {
        Regex("""^\s*(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)\s*$""").find(q)
            ?.let { return Pt(it.groupValues[1].toDouble(), it.groupValues[2].toDouble()) }
        val a = naver(p, "$NAVER/map-geocode/v2/geocode?query=" + java.net.URLEncoder.encode(q, "UTF-8"))
            .optJSONArray("addresses")
        require(a != null && a.length() > 0) { "주소를 찾지 못했어요" }
        val o = a.getJSONObject(0)
        return Pt(o.getString("y").toDouble(), o.getString("x").toDouble())
    }

    fun dist(a: Pt, b: Pt): Double { // meters
        val dLat = Math.toRadians(b.lat - a.lat); val dLng = Math.toRadians(b.lng - a.lng)
        val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLng / 2).pow(2)
        return 2 * 6371000.0 * asin(sqrt(h))
    }

    /** 네이버 실시간 최적 경로 → [분기점/톨게이트/출구 통과 직후 좌표 최대 max개] + 최종 목적지 */
    fun route(p: Prefs, from: Pt, to: Pt, max: Int): List<Pt> {
        val url = "$NAVER/map-direction/v1/driving?start=${from.lng},${from.lat}&goal=${to.lng},${to.lat}&option=traoptimal"
        val res = naver(p, url)
        val rt = res.optJSONObject("route")?.getJSONArray("traoptimal")?.getJSONObject(0)
            ?: error("경로 조회 실패: ${res.toString().take(100)}")
        val path = rt.getJSONArray("path"); val guide = rt.getJSONArray("guide")
        val pts = List(path.length()) { Pt(path.getJSONArray(it).getDouble(1), path.getJSONArray(it).getDouble(0)) }
        val wps = mutableListOf<Pt>()
        for (i in 0 until guide.length()) {
            if (wps.size >= max) break
            val g = guide.getJSONObject(i)
            val t = g.getString("instructions")
            if (listOf("분기점", "톨게이트", "출구").none { t.contains(it) }) continue
            var j = g.getInt("pointIndex"); var d = 0.0
            while (j < pts.lastIndex && d < 300) { d += dist(pts[j], pts[j + 1]); j++ } // 지점 통과 후 300m
            if (j < pts.lastIndex) wps += pts[j]
        }
        return wps + to
    }

    /** Tesla Fleet API (서명 프록시 경유)로 목적지 전송 */
    fun tesla(p: Prefs, pt: Pt) {
        val body = JSONObject().put("lat", pt.lat).put("lon", pt.lng).put("order", 0).toString()
        val r = Request.Builder()
            .url("${p.get("proxy").trimEnd('/')}/api/1/vehicles/${p.get("vin")}/command/navigation_gps_request")
            .header("Authorization", "Bearer ${p.get("token")}")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        http.newCall(r).execute().use {
            val txt = it.body?.string().orEmpty()
            check(it.isSuccessful && txt.contains("\"result\":true")) { "HTTP ${it.code} ${txt.take(80)}" }
        }
    }
}
