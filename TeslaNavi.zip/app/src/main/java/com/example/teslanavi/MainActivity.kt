package com.example.teslanavi

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.*
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            .launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS))
        val p = Prefs(this)
        setContent { MaterialTheme { Screen(p) } }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun Screen(p: Prefs) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var dest by remember { mutableStateOf("") }
    var n by remember { mutableStateOf(2f) }
    var km by remember { mutableStateOf(1f) }
    var status by remember { mutableStateOf("") }
    val keys = listOf("nid" to "Naver Client ID", "nsecret" to "Naver Client Secret",
        "proxy" to "Tesla 프록시 URL (https://...)", "vin" to "차량 VIN", "token" to "Tesla Access Token")
    val vals = remember { keys.map { mutableStateOf(p.get(it.first)) } }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEachIndexed { i, (k, label) ->
            OutlinedTextField(value = vals[i].value, onValueChange = { vals[i].value = it; p.put(k, it) },
                label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(value = dest, onValueChange = { dest = it },
            label = { Text("목적지 (주소 또는 위도,경도)") }, modifier = Modifier.fillMaxWidth())
        Text("자동 경유지 최대 ${n.toInt()}개")
        Slider(value = n, onValueChange = { n = it }, valueRange = 0f..8f, steps = 7)
        Text("경유지 전환 거리 ${"%.1f".format(km)} km")
        Slider(value = km, onValueChange = { km = it }, valueRange = 0.5f..3f)
        Button(modifier = Modifier.fillMaxWidth(), onClick = {
            status = "경로 조회 중…"
            LocationServices.getFusedLocationProviderClient(ctx)
                .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener { l ->
                    if (l == null) { status = "현재 위치를 못 가져왔어요"; return@addOnSuccessListener }
                    scope.launch {
                        status = try {
                            val wps = withContext(Dispatchers.IO) {
                                Api.route(p, Pt(l.latitude, l.longitude), Api.geocode(p, dest), n.toInt())
                            }
                            ctx.startForegroundService(Intent(ctx, NaviService::class.java)
                                .putExtra("wps", wps.flatMap { listOf(it.lat, it.lng) }.toDoubleArray())
                                .putExtra("radius", km * 1000.0))
                            "경유지 ${wps.size - 1}개 + 목적지로 순차 안내 시작"
                        } catch (e: Exception) { "오류: ${e.message}" }
                    }
                }
        }) { Text("순차 주행 안내 시작") }
        Text(status)
    }
}
